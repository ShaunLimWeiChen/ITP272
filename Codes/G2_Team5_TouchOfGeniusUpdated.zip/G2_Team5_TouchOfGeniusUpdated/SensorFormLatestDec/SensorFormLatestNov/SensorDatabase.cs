﻿namespace SensorFormLatestNov {
    
    
    public partial class SensorDatabase {
    }
}
